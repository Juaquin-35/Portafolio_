module.exports = async function getData(page) {
  await page.goto("https://misiir.sii.cl/cgi_misii/siihome.cgi");

  const name = await page.locator("#nameCntr").textContent();
  const rut2 = await page.locator("#rutCntr").textContent();
  const domicilio = await page.locator("#domiCntr").textContent();

  return {
    name: name.trim(),
    rut: rut2.trim(),
    domicilio: domicilio.trim(),
  };
};

