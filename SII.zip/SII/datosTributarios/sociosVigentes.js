module.exports = async function getSociosVigentes(page) {
  await page.goto("https://misiir.sii.cl/cgi_misii/siihome.cgi");
  await page.locator('a[href="#"][id="menu_datos_contribuyente"]').click();
  await page.waitForTimeout(500);

  const filas = await page.locator(
    'div[id="collapse4Cntrb"] div[id="no-more-tables"] table tbody tr'
  );

  const datosFilas = await filas.evaluateAll((filas) => {
    return filas.slice(0, filas.length - 2).map((fila) => {
      const celdas = fila.querySelectorAll("td");
      return Array.from(celdas).map((celda) => celda.textContent.trim());
    });
  });

  return datosFilas.map((fila) => ({
    Nombre: fila[0] || "",
    Rut: fila[1] || "",
    Porc_Capital: fila[4] || "",
    Porc_Utilidades: fila[5] || "",
    Fecha_de_incorporación: fila[6] || "",
  }));
};
