module.exports = async function getActividadesEconomicas(page) {
  await page.goto("https://misiir.sii.cl/cgi_misii/siihome.cgi");
  await page.locator('a[href="#"][id="menu_datos_contribuyente"]').click();
  await page.waitForTimeout(500);

  const fol = await page.locator(
    'div[id="collapse6Cntrb"] div[id="divActEcos"] div[id="no-more-tables"] div[id="tblIdGiros_wrapper"] div.row:nth-of-type(2) div[class="col-sm-12"] table tbody tr'
  );
  const actividades = await fol.evaluateAll((fol) => {
    return fol.map((fila) => {
      const celdas = fila.querySelectorAll("td");
      return Array.from(celdas).map((celda) => celda.textContent.trim());
    });
  });

  return actividades.map((fila) => ({
    Actividad: fila[0] || "",
    Codigo: fila[1] || "",
    Categoria_tributaria: fila[2] || "",
    Afecta_IVA: fila[3] || "",
    A_partir_de: fila[4] || "",
  }));
};
