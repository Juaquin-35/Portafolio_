module.exports = async function getRepresentantesLegales(page) {
  await page.goto("https://misiir.sii.cl/cgi_misii/siihome.cgi");
  await page.locator('a[href="#"][id="menu_datos_contribuyente"]').click();
  await page.waitForTimeout(500);

  await page
    .locator('a[href="#collapse2Cntrb"][class="arrow-click collapsed"]')
    .click();
  await page.waitForTimeout(500);

  const nom = await page
    .locator(
      'div[id="represVig"] div[id="no-more-tables"] table tbody tr:first-child td:nth-child(1)'
    )
    .textContent();
  const rot = await page
    .locator(
      'div[id="represVig"] div[id="no-more-tables"] table tbody tr:first-child td:nth-child(2)'
    )
    .textContent();
  const adp = await page
    .locator(
      'div[id="represVig"] div[id="no-more-tables"] table tbody tr:first-child td:nth-child(3)'
    )
    .textContent();

  return {
    nombre: nom.trim(),
    rut: rot.trim(),
    aPartirDe: adp.trim(),
  };
};
