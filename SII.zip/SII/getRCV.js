const { chromium } = require("playwright");
const dotenv = require("dotenv");
const XLSX = require("xlsx");
const fs = require("fs");
const path = require("path");

dotenv.config();

async function setupBrowser() {
  const browser = await chromium.launch({ headless: true });
  const context = await browser.newContext();
  const page = await context.newPage();
  return { browser, context, page };
}

async function login(page, rut, password) {
  await page.goto("https://homer.sii.cl/");
  await page.getByRole("button", { name: "Mi Sii" }).click();
  await page.waitForLoadState("networkidle");

  const rutField = await page.getByPlaceholder("Ej:");
  await rutField.click();
  for (const char of rut) {
    await rutField.press(char);
  }
  await page.waitForTimeout(500);
  await rutField.press("Tab");

  const passwordField = page.locator("#clave");
  await passwordField.click();
  for (const char of password) {
    await passwordField.press(char);
  }
  await page.waitForTimeout(500);
  await page.getByRole("button", { name: "Ingresar", exact: true }).click();
  await page.waitForLoadState("networkidle");

  const closeButton = page.getByRole("button", { name: "Cerrar" });
  if ((await closeButton.count()) > 0) {
    await closeButton.click();
  }
}

async function procesarArchivo(csvFilePath, tipo, rut) {
  function convertCsvToXlsx(csvFilePath, xlsxFilePath) {
    const csvData = fs.readFileSync(csvFilePath, "utf8");
    const rows = csvData.split("\n").map((row) => row.split(";"));
    const workbook = XLSX.utils.book_new();
    const worksheet = XLSX.utils.aoa_to_sheet(rows);
    XLSX.utils.book_append_sheet(workbook, worksheet, "Sheet1");
    XLSX.writeFile(workbook, xlsxFilePath);
  }

  function modificarEncabezadosYOrdenar(xlsxFilePath) {
    const workbook = XLSX.readFile(xlsxFilePath);
    const sheetName = workbook.SheetNames[0];
    const worksheet = workbook.Sheets[sheetName];
    const data = XLSX.utils.sheet_to_json(worksheet);

    const newHeaders = {
      "RUT Proveedor": "Rut Proveedor",
      "Rut cliente": "Rut Proveedor",
      "Razon Social": "Nombre Proveedor",
      Folio: "Nº Doc",
      "Fecha Docto": "Fecha Emisión",
      "Fecha Recepcion": "Fecha Registro",
      "Monto Neto": "Valor Total Neto",
      "Monto Exento": "Valor Exento",
      "Monto IVA Recuperable": "Valor IVA",
      "Monto Total": "Valor Total Doc.",
    };

    const modifiedData = data.map((row) => {
      const modifiedRow = {};
      for (const key in row) {
        const newKey = newHeaders[key] || key;
        modifiedRow[newKey] = row[key];
      }

      // Separar el RUT del proveedor en dos columnas
      const rutProveedor = modifiedRow["Rut Proveedor"];
      if (rutProveedor) {
        const rutParts = rutProveedor.split("-");
        let rutSinDV = rutParts[0];
        let dv = rutParts[1];

        if (!dv && rutParts.length === 1) {
          rutSinDV = rutProveedor.slice(0, -1);
          dv = rutProveedor.slice(-1);
        }

        modifiedRow["DV Proveedor"] = dv;
        modifiedRow["Rut Proveedor"] = rutSinDV;
      }

      return modifiedRow;
    });

    const newOrder = [
      "Tipo Doc",
      "Nº Doc",
      "Rut Proveedor",
      "DV Proveedor",
      "Nombre Proveedor",
      "Fecha Emisión",
      "Fecha Vencimiento",
      "Fecha Registro",
      "Valor Total Neto",
      "Valor Exento",
      "Valor IVA",
      "Valor IVA Retenido",
      "Valor Específico",
      "Valor Retención",
      "Valor Total Doc.",
      "Es Doc. Electr.(S)",
      "Código Cuenta Nº 1",
      "Centro Costos Nº 1",
      "Valor Detalle Neto 1",
      "Código Cuenta Nº 2",
      "Centro Costos Nº 2",
      "Valor Detalle Neto 2",
      "Código Cuenta Nº 3",
      "Centro Costos Nº 3",
      "Valor Detalle Neto 3",
      "Código Cuenta Nº 4",
      "Centro Costos Nº 4",
      "Valor Detalle Neto 4",
      "Código Cuenta Nº 5",
      "Centro Costos Nº 5",
      "Valor Detalle Neto 5",
      "Código Cuenta Nº 6",
      "Centro Costos Nº 6",
      "Valor Detalle Neto 6",
      "Código Cuenta Nº 7",
      "Centro Costos Nº 7",
      "Valor Detalle Neto 7",
      "Código Cuenta Nº 8",
      "Centro Costos Nº 8",
      "Valor Detalle Neto 8",
      "Código Cuenta Nº 9",
      "Centro Costos Nº 9",
      "Valor Detalle Neto 9",
      "Código Cuenta Nº 10",
      "Centro Costos Nº 10",
      "Valor Detalle Neto 10",
    ];

    const reorderedData = modifiedData.map((row) => {
      const reorderedRow = {};
      for (const header of newOrder) {
        reorderedRow[header] = row[header];
      }
      return reorderedRow;
    });

    const modifiedWorksheet = XLSX.utils.json_to_sheet(reorderedData);
    const newWorkbook = XLSX.utils.book_new();
    XLSX.utils.book_append_sheet(newWorkbook, modifiedWorksheet, sheetName);

    const downloadFolder = path.join(__dirname, "downloads");
    if (!fs.existsSync(downloadFolder)) {
      fs.mkdirSync(downloadFolder);
    }

    // Cambiar los nombres de los archivos a incluir el RUT y el tipo de documento
    const newFilePathXlsx = path.join(
      downloadFolder,
      `${rut}_R${tipo}_audisoft.xlsx`
    );
    XLSX.writeFile(newWorkbook, newFilePathXlsx);

    // Guardar archivo JSON como .txt
    const newFilePathJson = path.join(
      downloadFolder,
      `${rut}_R${tipo}_audisoft.txt`
    );

    fs.writeFileSync(
      newFilePathJson,
      JSON.stringify(reorderedData, null, 2),
      "utf-8"
    );

    //console.log(`Archivo XLSX de ${tipo} modificado guardado como: ${newFilePathXlsx}`);
    //console.log(`Archivo JSON de ${tipo} guardado como: ${newFilePathJson}`);

    // Eliminar el archivo XLSX original después de procesarlo
    fs.unlinkSync(xlsxFilePath);

    // Devolver las ubicaciones de los archivos generados
    return {
      xlsxFilePath: newFilePathXlsx,
      jsonFilePath: newFilePathJson,
    };
  }

  // Convertir el CSV a XLSX y guardar la ruta del archivo
  convertCsvToXlsx(csvFilePath, csvFilePath.replace(".csv", ".xlsx"));

  const csvData = fs.readFileSync(csvFilePath, "utf8");
  const originalRuts = csvData.split("\n").map((row) => row.split(";")[0]);

  return modificarEncabezadosYOrdenar(
    csvFilePath.replace(".csv", ".xlsx"),
    originalRuts
  );
}

async function Compra_venta(page, mes, anio, rut) {
  await page.goto("https://www4.sii.cl/consdcvinternetui/#/index");
  await page
    .locator(
      'div[class="panel-body"] div.form-group:nth-child(2) select[id="periodoMes"]'
    )
    .click();
  await page.waitForTimeout(500);
  await page.selectOption("#periodoMes", { label: mes });
  await page.waitForTimeout(500);
  await page
    .locator(
      'div[class="panel-body"] div.form-group:nth-child(2) select[ng-model="periodoAnho"]'
    )
    .click();
  await page.waitForTimeout(500);
  await page.selectOption('select[ng-model="periodoAnho"]', { label: anio });
  await page.waitForTimeout(500);
  await page.getByRole("button", { name: "Consultar", exact: true }).click();
  await page.waitForTimeout(500);
  await page.waitForLoadState("networkidle");

  const downloadPromise1 = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Descargar Detalles", exact: true })
    .click();
  const download1 = await downloadPromise1;
  const downloadFilePath1 = path.join(
    __dirname,
    "downloads",
    download1.suggestedFilename()
  );
  await download1.saveAs(downloadFilePath1);

  await page.waitForTimeout(500);

  await page.locator('a[href="#venta/"]').click();
  await page.waitForLoadState("networkidle");
  await page.waitForTimeout(500);

  const downloadPromise2 = page.waitForEvent("download");
  await page
    .getByRole("button", { name: "Descargar Detalles", exact: true })
    .click();
  const download2 = await downloadPromise2;
  const downloadFilePath2 = path.join(
    __dirname,
    "downloads",
    download2.suggestedFilename()
  );
  await download2.saveAs(downloadFilePath2);

  await page.waitForTimeout(500);

  // Procesar los archivos de compra y venta por separado
  const compraPaths = await procesarArchivo(downloadFilePath1, "C", rut);
  const ventaPaths = await procesarArchivo(downloadFilePath2, "V", rut);

  // Eliminar los archivos CSV originales
  fs.unlinkSync(downloadFilePath1);
  fs.unlinkSync(downloadFilePath2);

  console.log("Archivos procesados:");
  console.log("Compra: ", compraPaths);
  console.log("Venta: ", ventaPaths);
}

async function getRCV(page, options = {}) {
  const rut = options.rut || process.env.RUT;
  const password = options.password || process.env.PASSWORD_SII;
  const mes = options.mes || process.env.MES;
  const anio = options.anio || process.env.ANIO;

  const timeInicio = new Date();

  try {
    await login(page, rut, password);
    await page.goto("https://misiir.sii.cl/cgi_misii/siihome.cgi");
    const results = await Compra_venta(page, mes, anio, rut);

    const timeFin = new Date();
    const tiempoTotal = (timeFin - timeInicio) / 1000;
    console.log(`[RCV] Tiempo total de ejecución: ${tiempoTotal} segundos`);

    return results;
  } catch (error) {
    console.error("Error in getRCV:", error);
    throw error;
  }
}

module.exports = getRCV;
