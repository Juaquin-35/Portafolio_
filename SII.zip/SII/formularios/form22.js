const { chromium } = require('playwright');
const dotenv = require('dotenv');
const fs = require('fs');
const readline = require('readline'); // Para leer la entrada de la consola
const path = require('path');

dotenv.config({ path: path.resolve(__dirname, '..', '..', '..', '.env') });

// Crear una interfaz para leer la entrada del usuario desde la consola
const rl = readline.createInterface({
  input: process.stdin,
  output: process.stdout
});

function createLogStream(fileName) {
  return fs.createWriteStream(fileName, { flags: 'a' });
}

async function logInfo(option, data) {
  const logFileName = `${option.replace(/\s+/g, '_').toLowerCase()}.txt`;
  const logStream = createLogStream(logFileName);
  
  console.log = (...args) => {
    process.stdout.write(args.join(' ') + '\n');
    logStream.write(args.join(' ') + '\n');
  };
  console.log(data);
}

async function extractObservations(page) {
  const observationsData = await page.evaluate(() => {
    const table = document.querySelector('table[class="table table-bordered"]');
    const headerData = document.querySelector('table[class="table table-bordered"] thead tr:nth-child(2) th:nth-child(2)');
    const headerText = headerData ? headerData.innerText.trim() : '';

    if (table) {
      const rows = Array.from(table.querySelectorAll('tbody tr')).map(row => {
        const cells = Array.from(row.querySelectorAll('td')).map(cell => cell.innerText.trim());
        return cells;
      });

      const formattedData = rows.map(row => {
        return {
          "Obs.": headerText || '',
          "Codigo": row[0] || '',
          "Detalles": row[1] || '', 
        };
      });

      return formattedData;
    }
    return []; 
  });

  return observationsData;
}

module.exports = async function getformulario22(page) {
  const anio = process.env.ADO;
  
  // Dividir los años de la variable ANIO
  const años = anio.split(',').map(año => año.trim());
  
  // Inicializamos el navegador y el contexto
  const browser = await chromium.launch({ headless: false });
  const context = await browser.newContext();
  
  try {
    await page.goto('https://misiir.sii.cl/cgi_misii/siihome.cgi');
    console.log('');

    await page.waitForTimeout(500);
    await page.goto('https://www.sii.cl/servicios_online/1044-2696.html');
    await page.waitForTimeout(500);
    await page.locator('a[href="https://www4.sii.cl/consultaestadof22ui/"]').click();
    await page.waitForTimeout(500);
    await page.waitForLoadState('networkidle');
    await page.waitForTimeout(500);

    for (const año of años) {
      console.log(`Procesando año: ${año}`);
      await page.locator('select[data-ng-model="vm.selectedOption"]').click();
      await page.waitForTimeout(500);

      await page.selectOption('select[data-ng-model="vm.selectedOption"]', { label: año });
      await page.waitForLoadState('networkidle');
      await page.getByRole('button', { name: ' Consultar' }).click();
      await page.waitForLoadState('networkidle');
      await page.waitForTimeout(500);

      await page.locator('div[class="table-responsive"] table');
      await page.waitForLoadState('networkidle');
      const tableData = await page.evaluate(() => {
        const table = document.querySelector('div[class="table-responsive"]');
        const years = Array.from(table.querySelectorAll('thead th:not(:last-child)')).map(header => header.innerText.trim());
        const months = Array.from(table.querySelectorAll('tbody tr')).map(row => {
          const monthCell = row.querySelector('td');
          return monthCell ? monthCell.innerText.trim() : '';
        });

        const values = Array.from(table.querySelectorAll('tbody tr')).map(row => {
          const cells = Array.from(row.querySelectorAll('td:not(:last-child)')).map(cell => cell.innerText.trim());
          return cells;
        });

        const result = months.map((month, rowIndex) => {
          let rowData = { Fecha: month };
          years.forEach((year, colIndex) => {
            rowData[year] = values[rowIndex][colIndex] || '';
          });
          return rowData;
        });

        return result;
      });

      await logInfo('Formulario_22', tableData);
      console.log(JSON.stringify(''))
      console.log(JSON.stringify(''))
      console.log(JSON.stringify('Historial'))
      await page.waitForLoadState('networkidle');
      console.log(JSON.stringify(tableData, null, 2));
      console.log('');

      await page.getByRole('button', { name: ' Ver Certificado Solemne' }).click();
      await page.waitForTimeout(500);
      await page.waitForTimeout(500);

      const pageTitle = await page.evaluate(() => {
        const titleElement = document.querySelector('h2.col-xs-12.title');
        return titleElement ? titleElement.innerText.trim() : 'Título no encontrado';
      });
      console.log(JSON.stringify(''))
      console.log(JSON.stringify('Certificado Solemne'))
      console.log(JSON.stringify(''))
      console.log(pageTitle);

      const tabdt = await page.evaluate(() => {
        const table = document.querySelector('div[class="table-responsive"] table');
        const extractedHeaders = Array.from(table.querySelectorAll('thead th')).map(header => header.innerText.trim());
      
        const rows = Array.from(table.querySelectorAll('tbody tr')).map(row => {
          return Array.from(row.querySelectorAll('td')).map(cell => cell.innerText.trim());
        });

        const formattedData = rows.map(row => {
          const l = {
            "Titulo": row[0] || '',
            "Codigo": row[1] || '',
            "Monto": row[3] || ''
          };

          const I = {
            "Titulo": row[4] || '',
            "Codigo": row[5] || '',
            "Monto": row[7] || ''
          };

          return [
            {
              "Titulo": l.Titulo,
              "Codigo": l.Codigo,
              "Monto": l.Monto
            },
            {
              "Titulo": I.Titulo,
              "Codigo": I.Codigo,
              "Monto": I.Monto
            }
          ];
        });
      
        const extractds = {
          "Titulo": extractedHeaders[0] || '',
          "Codigo": extractedHeaders[1] || '',
          "Monto": extractedHeaders[3] || ''
        };
      
        let data = [];
        data.push(extractds);
      
        formattedData.forEach(item => {
          data.push(...item);
        });
      
        return {
          data
        };
      });

      console.log(JSON.stringify(tabdt, null, 2));

      console.log(JSON.stringify('Observaciónes'))

      await page.getByRole('button', { name: '×' }).click();
      await page.waitForLoadState('networkidle');
      
      const button = await page.getByRole('button', { name: ' Observaciones', exact: true });

      if (await button.isVisible()) {
          await page.getByRole('button', { name: ' Observaciones', exact: true }).click();
          const observationsData = await extractObservations(page);
          console.log(JSON.stringify(observationsData, null, 2));
      } else {
          console.log(JSON.stringify('No se han encontrado observaciones'));
      }

      await page.waitForTimeout(500);
      await page.goBack();
    }

  } finally {
    // Cerramos el navegador y el contexto después de terminar el trabajo
    await context.close();
    await browser.close();
  }
};
