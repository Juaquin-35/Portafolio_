import { test, expect } from '@playwright/test';

test('test', async ({ page }) => {
  // Recording...
});