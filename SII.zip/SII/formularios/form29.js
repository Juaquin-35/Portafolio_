const { chromium } = require('playwright');
const dotenv = require('dotenv');
const fs = require('fs');
const path = require('path');

// Cargar el archivo .env desde la raíz del proyecto (asumiendo que el script está en una subcarpeta)
dotenv.config({ path: path.resolve(__dirname, '..', '..', '..', '.env') });

function formatAmount(amount) {
    return amount.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ".");
}

const reorganizeDataByYearAndMonth = (jsonData) => {
    const reorganizedData = {};

    jsonData.forEach(row => {
        const mes = row.mes;

        Object.keys(row).forEach(year => {
            if (year !== 'mes') {
                if (!reorganizedData[year]) {
                    reorganizedData[year] = {};
                }

                if (!reorganizedData[year][mes]) {
                    reorganizedData[year][mes] = null;
                }

                reorganizedData[year][mes] = row[year];
            }
        });
    });

    const monthsOrder = ["Enero", "Febrero", "Marzo", "Abril", "Mayo", "Junio", "Julio", "Agosto", "Septiembre", "Octubre", "Noviembre", "Diciembre"];

    Object.keys(reorganizedData).forEach(year => {
        const yearData = reorganizedData[year];
        const sortedYearData = {};

        monthsOrder.forEach(month => {
            if (yearData[month]) {
                sortedYearData[month] = yearData[month];
            } else {
                sortedYearData[month] = null;
            }
        });

        reorganizedData[year] = sortedYearData;
    });

    return reorganizedData;
};

module.exports = async function getformulario29(page) {
    const browser = await chromium.launch({ headless: false });
    const context = await browser.newContext();

    try {
        console.log('');

        await page.waitForTimeout(500);
        await page.goto('https://www.sii.cl/servicios_online/1042-3266.html');
        await page.waitForTimeout(500);
        await page.locator('a[href="https://www4.sii.cl/sifmConsultaInternet/index.html?dest=cifxx&form=29"]').click();
        await page.waitForTimeout(800);
        await page.waitForSelector('table.gw-sii-tabla-interior');
        await page.waitForTimeout(800);
        await page.waitForTimeout(800);
        await page.locator('table.gw-sii-tabla-interior tbody tr:nth-child(1) td table tbody tr:nth-child(1) td table tbody tr:nth-child(2) td table tbody tr td table tbody tr td div[class="gwt-Hyperlink"] a[href="#29"]');
        await page.waitForTimeout(500);
        await page.waitForTimeout(500);
        await page.getByRole('link', { name: 'F29 (+)', exact: true }).click();
        await page.waitForTimeout(500);

        const mainTableSelector = 'table.gw-sii-tabla-interior tbody tr:nth-child(1) td table tbody tr:nth-child(1) td table tbody tr:nth-child(2) td table tbody tr td table tbody tr td:nth-child(2) table';

        const extractTableData = async (tableSelector) => {
            return await page.$$eval(`${tableSelector} tbody tr`, (rows) => {
                return rows.reverse().map(row => {
                    const cells = row.querySelectorAll('td');
                    return Array.from(cells).map(cell => cell.textContent.trim()).filter(cell => cell !== '' && cell !== '&nbsp;');
                });
            });
        };

        const mainTableData = await extractTableData(mainTableSelector);

        for (let i = 0; i < mainTableData.length; i++) {
            const nestedTableSelector = `table:nth-of-type(${i + 1})`;

            const nestedTableData = await page.$$eval(`${mainTableSelector} tr:nth-child(${i + 1}) ${nestedTableSelector}`, (nestedRows) => {
                return nestedRows.map(nestedRow => {
                    const nestedCells = nestedRow.querySelectorAll('td');
                    return Array.from(nestedCells).map(cell => cell.textContent.trim()).filter(cell => cell !== '' && cell !== '&nbsp;');
                });
            });

            if (nestedTableData.length > 0) {
                mainTableData[i].nestedTable = nestedTableData;
            }
        }

        const getAños = async (page) => {
            return await page.$$eval('table.gw-sii-tabla-interior tbody tr:nth-child(1) td table tbody tr:nth-child(1) td table tbody tr:nth-child(1) td table tbody tr:nth-child(2)', (years) => {
                return years.map(year => {
                    const text = year.innerText.trim().replace(/\s+/g, ', ').trim();
                    return text.split(', ').filter(item => /^\d{4}$/.test(item));
                }).flat();
            });
        };

        let años = await getAños(page);

        if (!años.includes('2019')) {
            console.error("El año 2019 no se ha encontrado.");
        }
        años = años.filter(año => año !== '&nbsp;');

        const reorganizeDataByYear = (mainTableData, años) => {
            const uniqueAños = [...new Set(años)].sort((a, b) => b - a);
            let result = [];

            mainTableData.forEach((row) => {
                if (row.length === 0) return;

                const mes = row[0];

                let rowData = { mes };

                const expectedColumns = uniqueAños.length + 1;
                if (row.length < expectedColumns) {
                    while (row.length < expectedColumns) {
                        row.shift();
                        row.unshift(null);
                        row.unshift(null);
                    }
                }

                uniqueAños.forEach((año, index) => {
                    let yearData = row[index + 1];
                    if (!yearData || yearData.trim() === '' || yearData.trim() === '&nbsp;') {
                        yearData = undefined;
                    }

                    rowData[año] = yearData !== undefined ? yearData : null;
                });

                result.push(rowData);
            });

            return result;
        };

        const jsonData = reorganizeDataByYear(mainTableData, años);

        const reorganizedData = reorganizeDataByYearAndMonth(jsonData);

        fs.writeFileSync('Formulario_29.txt', JSON.stringify(reorganizedData, null, 2));

        console.log(JSON.stringify("PERIODOS TRIBUTARIOS MENSUALES"));
        console.log(JSON.stringify(reorganizedData, null, 2));

        console.log("Los datos reorganizados por año y mes han sido guardados en 'Formulario_29.txt'");

    } finally {
        // Asegúrate de que `context` y `browser` están definidos
        await context.close();
        await browser.close();
    }
};
